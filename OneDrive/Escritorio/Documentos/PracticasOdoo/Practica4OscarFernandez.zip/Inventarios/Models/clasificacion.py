from odoo import models, fields

class Generos(models.Model):
    _name="clasificacion"