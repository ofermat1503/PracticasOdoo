{
    'name': 'Modulo Inventarios',
    'version': '1.0',
    'depends': ['base','contacts'],
    'author': 'oskita',
    'description': 'Modulo donde indicamos el modulo de Odoo',
    'data': ['views/navmenu.xml', 'views/vista.xml'],
    'installable': True
}